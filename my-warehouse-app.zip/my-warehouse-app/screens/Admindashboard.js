import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
  Linking,
  Alert,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useNavigation } from '@react-navigation/native';

const AdminDashboard = () => {
  const navigation = useNavigation();
  const webURL = 'https://palletpilot-admin.vercel.app';

  const openWebDashboard = () => {
    Linking.openURL(webURL).catch(() =>
      Alert.alert('Error', 'Could not open web dashboard.')
    );
  };

  const copyWebLink = async () => {
    await Clipboard.setStringAsync(webURL);
    Alert.alert('Copied', 'Web dashboard link copied to clipboard!');
  };

  return (
    <ImageBackground
      source={require('../assets/admin.jpg')}
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.title}>📊 Admin Dashboard</Text>

        <Text style={styles.sub}>✔️ Total Locations: 48</Text>
        <Text style={styles.sub}>📦 Used Locations: 36</Text>
        <Text style={styles.sub}>📈 Usage: 75%</Text>

        <Text style={styles.recent}>🕒 Recent Activity:</Text>
        <View style={styles.activityBox}>
          <Text style={styles.activity}>A1-01 - Carrots - 124 - IN</Text>
          <Text style={styles.activity}>B2-03 - Boxes - 50 - OUT</Text>
          <Text style={styles.activity}>D4-02 - Capsicum - 88 - IN</Text>
        </View>

        {/* Web Dashboard Buttons */}
        <View style={styles.bottomButtons}>
          <TouchableOpacity style={styles.webBtn} onPress={openWebDashboard}>
            <Text style={styles.btnText}>🌐 Open Web Dashboard</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.copyBtn} onPress={copyWebLink}>
            <Text style={styles.btnText}>📋 Copy Web Link</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.backText}>← Back to Home</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

export default AdminDashboard;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
  },
  sub: {
    fontSize: 16,
    color: 'white',
    marginBottom: 8,
  },
  recent: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 30,
    marginBottom: 10,
  },
  activityBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 14,
    borderRadius: 10,
  },
  activity: {
    fontSize: 15,
    marginBottom: 4,
  },
  bottomButtons: {
    marginTop: 30,
    alignItems: 'center',
  },
  webBtn: {
    backgroundColor: '#007BFF',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
    width: '100%',
    alignItems: 'center',
  },
  copyBtn: {
    backgroundColor: '#444',
    padding: 14,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
  },
  btnText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  backBtn: {
    marginTop: 20,
    alignItems: 'center',
  },
  backText: {
    color: 'white',
    textDecorationLine: 'underline',
    fontSize: 16,
  },
});
