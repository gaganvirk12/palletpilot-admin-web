import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const InwardsScreen = () => {
  const navigation = useNavigation();

  const [mode, setMode] = useState('Store'); // Store or Remove
  const [locationID, setLocationID] = useState('');
  const [ingredient, setIngredient] = useState('');
  const [quantity, setQuantity] = useState('');
  const [message, setMessage] = useState('');

  const [storedLocations, setStoredLocations] = useState([]);

  useEffect(() => {
    const loadLocations = async () => {
      const stored = await AsyncStorage.getItem('storedLocationIDs');
      if (stored) {
        setStoredLocations(JSON.parse(stored));
      }
    };
    loadLocations();
  }, []);

  const handleEnter = async () => {
    const trimmedLoc = locationID.trim().toUpperCase();

    if (!trimmedLoc) {
      alert('Please enter a Location ID');
      return;
    }

    if (!storedLocations.includes(trimmedLoc)) {
      alert('❌ Location ID not found in  list');
      return;
    }

    const log = {
      location: trimmedLoc,
      ingredient: ingredient.trim(),
      quantity: quantity.trim(),
      direction: mode === 'Store' ? 'IN' : 'OUT',
      timestamp: Date.now(),
    };

    const previousLogs = await AsyncStorage.getItem('inwardsLog');
    const logs = previousLogs ? JSON.parse(previousLogs) : [];
    await AsyncStorage.setItem('inwardsLog', JSON.stringify([...logs, log]));

    setMessage(
      mode === 'Store'
        ? '✅ Stored Successfully'
        : '❌ Removed Successfully'
    );

    // Reset fields
    setLocationID('');
    setIngredient('');
    setQuantity('');
  };

  return (
    <ImageBackground source={require('../assets/inwards.jpg')} style={styles.background}>
      <View style={styles.topButtons}>
        <TouchableOpacity style={styles.topBtn} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.topBtnText}>🏠 Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.topBtn} onPress={handleEnter}>
          <Text style={styles.topBtnText}>✅ Enter</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.container}>
        {/* Store/Remove Buttons */}
        <View style={styles.toggleContainer}>
          <TouchableOpacity
            style={[styles.toggleBtn, mode === 'Store' && styles.activeBtn]}
            onPress={() => setMode('Store')}
          >
            <Text style={styles.toggleText}>Store</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleBtn, mode === 'Remove' && styles.activeBtn]}
            onPress={() => setMode('Remove')}
          >
            <Text style={styles.toggleText}>Remove</Text>
          </TouchableOpacity>
        </View>

        {/* Location Input */}
        <TextInput
          style={styles.input}
          placeholder="📍 Enter Location ID"
          placeholderTextColor="gray"
          value={locationID}
          onChangeText={setLocationID}
        />

        {/* Ingredient & Quantity only for Store mode */}
        {mode === 'Store' && (
          <>
            <TextInput
              style={styles.input}
              placeholder="🧾 Ingredient / Pallet ID"
              placeholderTextColor="gray"
              value={ingredient}
              onChangeText={setIngredient}
            />
            <TextInput
              style={styles.input}
              placeholder="🔢 Quantity"
              placeholderTextColor="gray"
              value={quantity}
              onChangeText={setQuantity}
              keyboardType="default"
            />
          </>
        )}

        {/* Scan Barcode Button */}
        <TouchableOpacity style={styles.scanBtn}>
          <Text style={styles.scanBtnText}>📷 Scan Barcode</Text>
        </TouchableOpacity>

        {/* Status Message */}
        {message !== '' && (
          <Text
            style={[
              styles.message,
              message.includes('✅') ? styles.success : styles.removed,
            ]}
          >
            {message}
          </Text>
        )}
      </View>
    </ImageBackground>
  );
};

export default InwardsScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  topButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 40,
    paddingHorizontal: 20,
  },
  topBtn: {
    backgroundColor: 'tomato',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
  },
  topBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
  },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  toggleBtn: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginHorizontal: 10,
    backgroundColor: 'gray',
    borderRadius: 10,
  },
  activeBtn: {
    backgroundColor: 'dodgerblue',
  },
  toggleText: {
    color: 'white',
    fontWeight: 'bold',
  },
  input: {
    backgroundColor: 'white',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
    fontSize: 16,
  },
  scanBtn: {
    backgroundColor: '#333',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  scanBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
  message: {
    marginTop: 20,
    fontSize: 16,
    textAlign: 'center',
    padding: 12,
    borderRadius: 10,
  },
  success: {
    backgroundColor: '#d4edda',
    color: '#155724',
  },
  removed: {
    backgroundColor: '#f8d7da',
    color: '#721c24',
  },
});
