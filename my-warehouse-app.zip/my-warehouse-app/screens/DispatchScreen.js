import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ImageBackground,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DispatchScreen = () => {
  const navigation = useNavigation();
  const [palletID, setPalletID] = useState('');
  const [destination, setDestination] = useState('');

  const handleDispatch = async () => {
    if (!palletID.trim()) {
      Alert.alert('Please enter or scan a Pallet ID');
      return;
    }

    const logEntry = {
      palletID: palletID.trim(),
      destination: destination.trim(),
      timestamp: new Date().toISOString(),
      type: 'DISPATCH',
    };

    try {
      const logs = await AsyncStorage.getItem('logHistory');
      const parsed = logs ? JSON.parse(logs) : [];
      parsed.push(logEntry);
      await AsyncStorage.setItem('logHistory', JSON.stringify(parsed));
      Alert.alert('✅ Pallet Dispatched Successfully');
      setPalletID('');
      setDestination('');
    } catch (error) {
      Alert.alert('Error saving dispatch log');
    }
  };

  return (
    <ImageBackground
      source={require('../assets/home.jpg')}
      style={styles.background}
    >
      <View style={styles.topButtons}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Text style={styles.topBtnText}>🏠 Home</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleDispatch}>
          <Text style={styles.topBtnText}>✅ Enter</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.container}>
        <TextInput
          placeholder="Scan/Enter Pallet ID"
          placeholderTextColor="gray"
          value={palletID}
          onChangeText={setPalletID}
          style={styles.input}
        />

        <TextInput
          placeholder="Dispatch To (Optional)"
          placeholderTextColor="gray"
          value={destination}
          onChangeText={setDestination}
          style={styles.input}
        />

        <TouchableOpacity style={styles.scanBtn}>
          <Text style={styles.scanBtnText}>📷 Scan Barcode</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dispatchBtn} onPress={handleDispatch}>
          <Text style={styles.dispatchText}>🚚 Dispatch</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

export default DispatchScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  topButtons: {
    position: 'absolute',
    top: 50,
    left: 20,
    right: 20,
    zIndex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  topBtnText: {
    fontSize: 16,
    color: 'white',
    backgroundColor: 'tomato',
    padding: 10,
    borderRadius: 6,
    fontWeight: 'bold',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    marginTop: 80,
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 14,
    fontSize: 16,
    marginBottom: 15,
    color: 'black',
  },
  scanBtn: {
    backgroundColor: 'gray',
    padding: 12,
    alignItems: 'center',
    borderRadius: 10,
    marginBottom: 20,
  },
  scanBtnText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  dispatchBtn: {
    backgroundColor: 'green',
    padding: 15,
    alignItems: 'center',
    borderRadius: 10,
  },
  dispatchText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
