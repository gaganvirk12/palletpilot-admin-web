import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';

const SubscribeScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Home Button */}
      <TouchableOpacity
        style={styles.homeBtn}
        onPress={() => navigation.navigate('Home')}
      >
        <Text style={styles.homeText}>🏠 Home</Text>
      </TouchableOpacity>

      <Text style={styles.title}>🎉 Start Your 7-Day Free Trial</Text>
      <Text style={styles.subtitle}>
        Unlock all features including real-time inventory, barcode scanning, and analytics.
      </Text>

      <Text style={styles.benefits}>✅ No credit card required</Text>
      <Text style={styles.benefits}>✅ Cancel anytime during trial</Text>
      <Text style={styles.benefits}>🟡 Ads may be served during the trial</Text>

      {/* Animated Subscribe Button */}
      <Animatable.View animation="bounceIn" duration={1500}>
        <TouchableOpacity
          style={styles.subscribeBtn}
          onPress={() => console.log('Subscribe Clicked')}
        >
          <Text style={styles.subscribeText}>🚀 Start Free Trial</Text>
        </TouchableOpacity>
      </Animatable.View>
    </ScrollView>
  );
};

export default SubscribeScreen;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#121212',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeBtn: {
    position: 'absolute',
    top: 40,
    left: 20,
    padding: 10,
    backgroundColor: 'tomato',
    borderRadius: 20,
  },
  homeText: {
    color: 'white',
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 20,
  },
  benefits: {
    color: 'lime',
    fontSize: 16,
    marginVertical: 4,
  },
  subscribeBtn: {
    backgroundColor: 'dodgerblue',
    paddingVertical: 14,
    paddingHorizontal: 25,
    borderRadius: 10,
    marginTop: 30,
  },
  subscribeText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
