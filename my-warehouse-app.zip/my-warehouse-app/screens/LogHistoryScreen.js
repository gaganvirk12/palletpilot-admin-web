import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const LogHistoryScreen = () => {
  const [logs, setLogs] = useState([]);
  const [search, setSearch] = useState('');
  const navigation = useNavigation();

  useEffect(() => {
    const loadLogs = async () => {
      const stored = await AsyncStorage.getItem('inwardsLog');
      if (stored) {
        setLogs(JSON.parse(stored).reverse());
      }
    };

    const unsubscribe = navigation.addListener('focus', loadLogs);
    return unsubscribe;
  }, [navigation]);

  const filtered = logs.filter((log) =>
    log.location.toLowerCase().includes(search.toLowerCase()) ||
    log.ingredient.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <View
      style={[
        styles.logItem,
        { backgroundColor: item.direction === 'IN' ? '#e0ffe0' : '#ffe0e0' },
      ]}
    >
      <Text style={styles.logText}>
        📍 {item.location} - {item.ingredient || 'N/A'} - {item.quantity || '-'} -{' '}
        {item.direction} - {new Date(item.timestamp).toLocaleString()}
      </Text>
    </View>
  );

  return (
    <ImageBackground
      source={require('../assets/inwards.jpg')}
      style={{ flex: 1 }}
    >
      <View style={styles.container}>
        <TextInput
          placeholder="Search by location or ingredient"
          placeholderTextColor="gray"
          value={search}
          onChangeText={setSearch}
          style={styles.search}
        />
        <FlatList
          data={filtered}
          keyExtractor={(_, i) => i.toString()}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      </View>
      <TouchableOpacity
  style={styles.homeBtn}
  onPress={() => navigation.navigate('Home')}
>
  <Text style={styles.homeBtnText}>🏠 Home</Text>
</TouchableOpacity>

    </ImageBackground>
  );
};

export default LogHistoryScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  search: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  logItem: {
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  logText: {
    fontSize: 16,
    color: '#333',
  },
  homeBtn: {
  position: 'absolute',
  bottom: 20,
  left: 20,
  backgroundColor: 'rgb(0, 123, 255)',
  paddingVertical: 12,
  paddingHorizontal: 20,
  borderRadius: 30,
  elevation: 5,
},
homeBtnText: {
  color: 'white',
  fontWeight: 'bold',
  fontSize: 16,
},
});
