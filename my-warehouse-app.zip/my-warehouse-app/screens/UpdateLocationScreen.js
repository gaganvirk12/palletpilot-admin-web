import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ImageBackground,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const STORAGE_KEY = 'storedLocationIDs';

const UpdateLocationScreen = () => {
  const navigation = useNavigation();
  const [location, setLocation] = useState('');
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    loadLocations();
  }, []);

  const loadLocations = async () => {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (stored) {
      setLocations(JSON.parse(stored));
    }
  };

  const saveLocation = async () => {
    const newLocation = location.trim().toUpperCase();
    if (!newLocation) {
      alert('Location ID cannot be empty.');
      return;
    }

    if (locations.includes(newLocation)) {
      alert('Location already exists.');
      return;
    }

    const updated = [...locations, newLocation];
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setLocations(updated);
    setLocation('');
  };

  const deleteLocation = async (locToDelete) => {
    Alert.alert(
      'Delete Location',
      `Are you sure you want to delete ${locToDelete}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            const filtered = locations.filter((loc) => loc !== locToDelete);
            await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
            setLocations(filtered);
          },
        },
      ]
    );
  };

  return (
    <ImageBackground
      source={require('../assets/updatelocation.jpg')}
      style={styles.background}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>📍 Update Location IDs</Text>

        <TextInput
          style={styles.input}
          placeholder="Enter Location ID/Scan Barcode"
          placeholderTextColor="gray"
          value={location}
          onChangeText={setLocation}
        />
        

        <TouchableOpacity style={styles.saveBtn} onPress={saveLocation}>
          <Text style={styles.saveBtnText}>➕ Save Location</Text>
        </TouchableOpacity>
        
  {/* 👇 New Scan Barcode Button (functionality to come later) */}
  <TouchableOpacity style={styles.scanBtn} onPress={() => alert('Scan function coming soon')}>
    <Text style={styles.scanBtnText}>📷 Scan Barcode</Text>
  </TouchableOpacity>

        <Text style={styles.subTitle}>📋 Stored Locations:</Text>

        {locations.map((loc, i) => (
          <View key={i} style={styles.locationRow}>
            <Text style={styles.locationText}>{loc}</Text>
            <TouchableOpacity onPress={() => deleteLocation(loc)}>
              <Text style={styles.deleteBtn}>🗑️</Text>
            </TouchableOpacity>
          </View>
        ))}

        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backBtnText}>🏠 Back to Home</Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
};

export default UpdateLocationScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    padding: 50,
    paddingTop: 50,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 15,
    textAlign: 'center',
    paddingTop:20,
  },
  input: {
    backgroundColor: 'white',
    padding: 14,
    borderRadius: 10,
    fontSize: 15,
    marginBottom: 10,
  },
  saveBtn: {
    backgroundColor: 'green',
    padding: 25,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 30,
  },
  saveBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
  subTitle: {
    fontSize: 18,
    color: 'white',
    marginBottom: 10,
  },
  locationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.9)',
    padding: 17,
    borderRadius: 15,
    marginBottom: 8,
  },
  locationText: {
    fontSize: 16,
    color: '#333',
  },
  deleteBtn: {
    fontSize: 18,
    color: 'red',
  },
  backBtn: {
    marginTop: 30,
    backgroundColor: 'tomato',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  backBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
  scanBtn: {
  backgroundColor: 'tomato',
  padding: 20,
  borderRadius: 10,
  alignItems: 'center',
  marginTop: 10,
},
scanBtnText: {
  color: 'white',
  fontWeight: 'bold',
},

});
