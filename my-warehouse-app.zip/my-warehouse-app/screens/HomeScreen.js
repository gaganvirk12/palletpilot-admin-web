import React, { useState, useCallback } from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ImageBackground,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';
const HomeScreen = () => {
  const navigation = useNavigation();
  const [storagePercent, setStoragePercent] = useState(0);

useFocusEffect(
  useCallback(() => {
    const calculateStorage = async () => {
      try {
        const locationsData = await AsyncStorage.getItem('storedLocationIDs');
        const logData = await AsyncStorage.getItem('inwardsLog');

        const totalLocations = locationsData ? JSON.parse(locationsData) : [];
        const logs = logData ? JSON.parse(logData) : [];

        const latestActions = {}; // { location: 'IN' | 'OUT' }

        // Reverse to make sure latest comes first
        [...logs].reverse().forEach((entry) => {
          if (!latestActions[entry.location]) {
            latestActions[entry.location] = entry.direction;
          }
        });

        const usedLocations = Object.keys(latestActions).filter(
          (loc) => latestActions[loc] === 'IN'
        );

        const percentUsed =
          totalLocations.length > 0
            ? Math.round((usedLocations.length / totalLocations.length) * 100)
            : 0;

        setStoragePercent(percentUsed);
      } catch (e) {
        console.error('❌ Error calculating storage:', e);
      }
    };

    calculateStorage();
  }, [])
);


  return (
    <ImageBackground
      source={require('../assets/home.jpg')}
      style={styles.background}
    >
      <View style={styles.container}>
        {/* Top Navbar */}
        <View style={styles.navbarContainer}>
          <View style={styles.navbar}>
            <Text style={styles.navbarTitle}>WMS</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Auth')}>
              <Text style={styles.signInText}>Sign In / Sign Up</Text>
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Welcome Section */}
          <View style={styles.welcomeSection}>
            <Text style={styles.header}>Welcome to PalletPilot</Text>
            <Text style={styles.subHeader}>📦 PalletPilot Benefits:</Text>
          </View>

          {/* Points */}
          <View style={styles.pointsSection}>
            <Text style={styles.point}>1. Streamlines receiving, storing & dispatch</Text>
            <Text style={styles.point}>2. Improves inventory tracking & accuracy</Text>
            <Text style={styles.point}>3. Provides real-time updates</Text>
            <Text style={styles.point}>4. Reduces human error</Text>
            <Text style={styles.point}>5. Optimizes warehouse operations</Text>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionButtonGroup}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('InwardsScreen')}
            >
              <Text style={styles.buttonText}>📦 Inwards</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('DispatchScreen')}
            >
              <Text style={styles.buttonText}>🚚 Dispatch</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('UpdateLocationScreen')}
            >
              <Text style={styles.buttonText}>🛠️ Update Location ID's</Text>
            </TouchableOpacity>
          </View>

          {/* Extras */}
          <View style={styles.extrasSection}>
            <TouchableOpacity
  style={styles.extraBtn}
  onPress={() => navigation.navigate('SubscribeScreen')} // ✅ This must match the screen name
>
  <Text style={styles.extraText}>📅 Subscription</Text>
</TouchableOpacity>

            <TouchableOpacity style={styles.extraBtn}>
              <Text style={styles.extraText}>📤 Export</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.extraBtn}
              onPress={() => navigation.navigate('LogHistoryScreen')}
            >
              <Text style={styles.extraText}>📜 Log History</Text>
            </TouchableOpacity>
          </View>

          {/* Storage */}
          <View style={styles.storageSection}>
            <Text style={styles.storageText}>📊 Storage: {storagePercent}% Used</Text>
            <View style={styles.storageBar}>
              <View style={[styles.storageBarFill, { width: `${storagePercent}%` }]} />
            </View>
          </View>
        </ScrollView>

        {/* Floating Buttons */}
        <View style={styles.floatingButtonsContainer}>
          <TouchableOpacity style={styles.contactBtn}>
            <Text style={styles.contactText}>📞 Contact</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.adminLoginBtn}
            onPress={() => navigation.navigate('AdminLoginScreen')}
          >
            <Text style={styles.buttonText}>🔑 Admin Login</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  navbarContainer: {
    marginBottom: 20,
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  navbarTitle: {
    color: 'white',
    fontSize: 26,
    fontWeight: 'bold',
  },
  signInText: {
    color: 'tomato',
    fontSize: 16,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  welcomeSection: {
    marginBottom: 10,
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 6,
  },
  subHeader: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  pointsSection: {
    marginBottom: 20,
  },
  point: {
    color: 'white',
    fontSize: 16,
    marginBottom: 5,
  },
  actionButtonGroup: {
    marginBottom: 30,
  },
  button: {
    backgroundColor: 'rgb(0, 123, 255)',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
  extrasSection: {
    marginBottom: 30,
  },
  extraBtn: {
    backgroundColor: 'rgb(34, 139, 34)',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  extraText: {
    color: 'white',
    fontSize: 18,
  },
  storageSection: {
    marginBottom: 30,
  },
  storageText: {
    color: 'white',
    fontSize: 16,
    marginBottom: 5,
  },
  storageBar: {
    height: 12,
    backgroundColor: '#666',
    borderRadius: 6,
    overflow: 'hidden',
  },
  storageBarFill: {
    height: '100%',
    backgroundColor: 'limegreen',
  },
  floatingButtonsContainer: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  contactBtn: {
    backgroundColor: 'tomato',
    padding: 14,
    borderRadius: 30,
  },
  contactText: {
    color: 'white',
    fontWeight: 'bold',
  },
  adminLoginBtn: {
    backgroundColor: 'gray',
    padding: 14,
    borderRadius: 30,
  },
});
