import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const AuthScreen = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [company, setCompany] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const navigation = useNavigation();

  const handleToggleMode = () => {
    setIsSignUp(!isSignUp);
    // Clear fields when switching
    setCompany('');
    setName('');
    setEmail('');
    setPhone('');
    setPassword('');
  };

  const handleSubmit = () => {
    Alert.alert('✅', isSignUp ? 'Sign Up submitted!' : 'Sign In submitted!');
  };

  return (
    <ImageBackground source={require('../assets/home.jpg')} style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.title}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>

        {isSignUp && (
          <>
            <TextInput
              style={styles.input}
              placeholder="Company Name (optional)"
              placeholderTextColor="#aaa"
              value={company}
              onChangeText={setCompany}
            />
            <TextInput
              style={styles.input}
              placeholder="Full Name"
              placeholderTextColor="#aaa"
              value={name}
              onChangeText={setName}
            />
            <TextInput
              style={styles.input}
              placeholder="Phone Number"
              placeholderTextColor="#aaa"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
            />
          </>
        )}

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#aaa"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor="#aaa"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>
            {isSignUp ? 'Sign Up' : 'Sign In'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={handleToggleMode}>
          <Text style={styles.toggleText}>
            {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.googleBtn}>
          <Text style={styles.googleText}>🔐 Sign Up with Google</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => Alert.alert('📌 T&C', 'Coming soon...')}>
          <Text style={styles.termsText}>✅ Please confirm our Terms & Conditions</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.homeBtn}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.homeText}>🏠 Home</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

export default AuthScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  title: {
    fontSize: 26,
    color: 'white',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
    fontSize: 16,
  },
  button: {
    backgroundColor: 'tomato',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
  },
  toggleText: {
    color: 'white',
    textAlign: 'center',
    marginTop: 15,
    fontSize: 15,
  },
  googleBtn: {
    marginTop: 20,
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  googleText: {
    fontWeight: 'bold',
    color: 'black',
  },
  termsText: {
    marginTop: 20,
    color: 'lightblue',
    textAlign: 'center',
  },
  homeBtn: {
    position: 'absolute',
    bottom: 30,
    right: 20,
    backgroundColor: 'blue',
    padding: 12,
    borderRadius: 20,
  },
  homeText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
