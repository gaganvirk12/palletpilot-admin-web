import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AdminDashboardWeb = () => {
  const [logs, setLogs] = useState([]);
  const [totalLocations, setTotalLocations] = useState(0);
  const [usedLocations, setUsedLocations] = useState(0);

  useEffect(() => {
    const loadDashboardData = async () => {
      const loc = await AsyncStorage.getItem('storedLocationIDs');
      const log = await AsyncStorage.getItem('inwardsLog');

      const locations = loc ? JSON.parse(loc) : [];
      const logData = log ? JSON.parse(log) : [];

      setTotalLocations(locations.length);

      const used = [...new Set(logData.filter(entry => entry.direction === 'IN').map(e => e.location))];
      setUsedLocations(used.length);

      setLogs(logData.reverse().slice(0, 5)); // Last 5 logs
    };

    loadDashboardData();
  }, []);

  const storagePercent = totalLocations > 0
    ? Math.round((usedLocations / totalLocations) * 100)
    : 0;

  const renderItem = ({ item }) => (
    <View style={[styles.logItem, { backgroundColor: item.direction === 'IN' ? '#e0ffe0' : '#ffe0e0' }]}>
      <Text style={styles.logText}>
        📦 {item.location} - {item.ingredient || '-'} - {item.quantity || '-'} - {item.direction} - {new Date(item.timestamp).toLocaleString()}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🌐 Admin Web Dashboard</Text>

      <View style={styles.summary}>
        <Text style={styles.summaryText}>📍 Total Locations: {totalLocations}</Text>
        <Text style={styles.summaryText}>📦 Used Locations: {usedLocations}</Text>
        <Text style={styles.summaryText}>📊 Storage Usage: {storagePercent}%</Text>
      </View>

      <Text style={styles.subHeader}>🕒 Recent Activity:</Text>
      <FlatList
        data={logs}
        keyExtractor={(_, i) => i.toString()}
        renderItem={renderItem}
      />
    </View>
  );
};

export default AdminDashboardWeb;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    backgroundColor: '#f4f4f4',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 20,
    textAlign: 'center',
  },
  summary: {
    marginBottom: 30,
  },
  summaryText: {
    fontSize: 18,
    marginBottom: 8,
    color: '#333',
  },
  subHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#444',
  },
  logItem: {
    padding: 14,
    marginBottom: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  logText: {
    fontSize: 16,
    color: '#222',
  },
});
